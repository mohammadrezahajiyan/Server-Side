﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mohammad_reza_hajiyan.Models;
using System.Text.RegularExpressions;
using System.ComponentModel.DataAnnotations;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;

namespace mohammad_reza_hajiyan.Controllers;

public class HomeController : Controller
{
    private readonly ConnectionDB db;
    private readonly ILogger<HomeController> _logger;


    public HomeController(ILogger<HomeController> logger, ConnectionDB ConnectionDB)
    {
        db = ConnectionDB;
        _logger = logger;
    }

    public IActionResult Index()
    {
        /* start select */
        var query = db.Users.ToList().OrderByDescending(x => x.user_id);
        var querycountuser = db.Users.ToList().Count;
        /* end select */
        ViewBag.countuser = querycountuser;
        return View(query);
    }
    public IActionResult Login()
    {
        return View();
    }
    public IActionResult action_register(users obj)
    {
        if (ModelState.IsValid)
        {
            // اعتبارسنجی و ثبت اطلاعات
            obj.dateregister = DateTime.Now;

            if (string.IsNullOrWhiteSpace(obj.nameandfamilyname))
            {
                TempData["ErrorMessage"] = "نام و نام خانوادگی را وارد کنید.";
                return RedirectToAction("Register");
            }

            if (string.IsNullOrWhiteSpace(obj.email))
            {
                TempData["ErrorMessage"] = "آدرس ایمیل را وارد کنید.";
                return RedirectToAction("Register");
            }
            if (string.IsNullOrWhiteSpace(obj.phone))
            {
                TempData["ErrorMessage"] = "شماره تلفن را وارد کنید.";
                return RedirectToAction("Register");
            }

            if (string.IsNullOrWhiteSpace(obj.password))
            {
                TempData["ErrorMessage"] = "رمز عبور را وارد کنید.";
                return RedirectToAction("Register");
            }
            if (string.IsNullOrWhiteSpace(obj.repassword))
            {
                TempData["ErrorMessage"] = "تکرار رمز عبور را وارد کنید.";
                return RedirectToAction("Register");
            }

            // اعتبارسنجی آدرس ایمیل
            var emailAttribute = new EmailAddressAttribute();
            if (!emailAttribute.IsValid(obj.email))
            {
                TempData["ErrorMessage"] = "آدرس ایمیل وارد شده معتبر نیست. لطفاً یک آدرس ایمیل معتبر وارد کنید.";
                return RedirectToAction("Register");
            }
            // اعتبارسنجی شماره تلفن
            var phoneRegex = new Regex(@"^09\d{9}$");
            if (!phoneRegex.IsMatch(obj.phone))
            {
                TempData["ErrorMessage"] = "شماره تلفن وارد شده معتبر نیست. لطفاً یک شماره موبایل معتبر وارد کنید.";
                return RedirectToAction("Register");
            }
            if (!IsPasswordValid(obj.password))
            {
                TempData["ErrorMessage"] = "رمز عبور باید حداقل 8 رقم، حاوی حروف بزرگ و کوچک، عدد و یک کاراکتر ویژه باشد.";
                return RedirectToAction("Register");
            }
            if (obj.password != obj.repassword)
            {
                TempData["ErrorMessage"] = "رمزهای عبور وارد شده یکسان نیستند.";
                return RedirectToAction("Register");
            }

            // چک کردن تکراری بودن آدرس ایمیل
            if (IsEmailAlreadyRegistered(obj.email))
            {
                TempData["ErrorMessage"] = "ایمیل وارد شده قبلاً ثبت نام کرده است.";
                return RedirectToAction("Register");
            }

            if (IsphoneAlreadyRegistered(obj.phone))
            {
                TempData["ErrorMessage"] = "شماره تلفن وارد شده قبلاً ثبت نام کرده است.";
                return RedirectToAction("Register");
            }


            // ثبت نام در دیتابیس
            db.Users.Add(obj);
            db.SaveChanges();

            TempData["SuccessMessage"] = "ثبت نام با موفقیت انجام شد.";
            Response.Cookies.Append("state_login", "true");
            return RedirectToAction("Register");
        }

        // در صورت وجود خطاها، اطلاعات به همان صفحه باز می‌گردد
        TempData["ErrorMessage"] = "خطا در ثبت نام. لطفاً موارد خواسته شده را به درستی وارد کنید.";
        return RedirectToAction("Register");
    }

    public JsonResult IsEmailAvailable(string email)
    {
        bool isEmailAvailable = !IsEmailAlreadyRegistered(email);
        return Json(isEmailAvailable);
    }
    private bool IsEmailAlreadyRegistered(string email)
    {
        return db.Users.Any(u => u.email == email);
    }

    public JsonResult IsPhoneAvailable(string phone)
    {
        bool IsPhoneAvailable = !IsphoneAlreadyRegistered(phone);
        return Json(IsPhoneAvailable);
    }
    private bool IsphoneAlreadyRegistered(string phone)
    {
        return db.Users.Any(u => u.phone == phone);
    }
    private bool IsPasswordValid(string password)
    {
        // حداقل 8 رقم
        if (password.Length < 8)
            return false;

        // حداقل یک حرف بزرگ
        if (!password.Any(char.IsUpper))
            return false;

        // حداقل یک حرف کوچک
        if (!password.Any(char.IsLower))
            return false;

        // حداقل یک عدد
        if (!password.Any(char.IsDigit))
            return false;

        // حداقل یک کاراکتر ویژه
        if (!password.Any(c => !char.IsLetterOrDigit(c)))
            return false;

        return true;
    }



    public IActionResult Register()
    {
        /* start insert */
        // users obj = new users();
        // obj.nameandfamilyname = "mohammad reza hajiyan";
        // obj.email = "hajiyan@gmail.com";
        // obj.phone = "09912628987";
        // obj.password = "reza1397";
        // obj.dateregister = DateTime.Now;
        // string repassword = "reza1397";
        // if (obj.password == repassword)
        // {
        //     db.Users.Add(obj);
        //     db.SaveChanges();
        // }
        /* end insert */
        /* start select */
        // var query = db.Users.ToList().OrderByDescending(x => x.user_id);
        // var querycountuser = db.Users.ToList().Count;
        // /* end select */
        // ViewBag.countuser = querycountuser;
        // return View(query);
        return View();
    }
    public IActionResult Contact()
    {
        return View();
    }

    public IActionResult About()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }
    public IActionResult question_order()
    {
        return View();
    }
    public IActionResult question_send_order()
    {
        return View();
    }
    public IActionResult return_product()
    {
        return View();
    }
    public IActionResult terms()
    {
        return View();
    }
    public IActionResult question_payment()
    {
        return View();
    }
    public IActionResult samsung()
    {
        return View();
    }
    public IActionResult apple()
    {
        return View();
    }
    public IActionResult huawei()
    {
        return View();
    }
    public IActionResult xiaomi()
    {
        return View();
    }


    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
