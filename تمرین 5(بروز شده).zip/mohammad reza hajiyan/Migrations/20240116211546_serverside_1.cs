﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace mohammad_reza_hajiyan.Migrations
{
    public partial class serverside_1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
