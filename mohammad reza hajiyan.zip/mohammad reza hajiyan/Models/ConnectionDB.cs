using System.Security.Cryptography.X509Certificates;
using Microsoft.EntityFrameworkCore;

namespace mohammad_reza_hajiyan.Models
{
    public class ConnectionDB:DbContext
    {
        public ConnectionDB(DbContextOptions options):base(options)
        {
        }
        public DbSet<users> Users{get; set;}
        public DbSet<products> Products{get; set;}
    }
}