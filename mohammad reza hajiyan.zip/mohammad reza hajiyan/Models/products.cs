using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace mohammad_reza_hajiyan.Models
{
    public class products
    {
        [Required]
        [Key]
        public int pro_code {get; set;}
        
        [StringLength(100)]
        [Required]
        public string pro_name {get; set;}

        [StringLength(100)]
        [Required]
        public string pro_brand {get; set;}

        [Required]
        public int pro_qty {get; set;}

        [Required]
        public float pro_price {get; set;}

        public int? pro_price_offer {get; set;}

        [StringLength(500)]
        [Required]
        public string pro_image {get; set;}
        
        [Required]
        public string pro_detail {get; set;}
    }
}