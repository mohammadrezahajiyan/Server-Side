using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace mohammad_reza_hajiyan.Models
{
    public class users
    {
        [Required]
        [Key]
        public int user_id {get; set;}
        
        [StringLength(100)]
        [Required]
        public string nameandfamilyname {get; set;}

        [StringLength(70)]
        [Required]
        public string email {get; set;}
        
        [StringLength(32)]
        [Required]
        public string password {get; set;}
        
        [StringLength(32)]
        [Required]
        public string repassword {get; set;}
        
        [StringLength(11)]
        [Required]
        public string phone {get; set;}
        
    }
}