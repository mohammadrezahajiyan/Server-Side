﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace mohammad_reza_hajiyan.Migrations
{
    public partial class serverside_2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Products",
                columns: table => new
                {
                    pro_code = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    pro_name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    pro_brand = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    pro_qty = table.Column<int>(type: "int", nullable: false),
                    pro_price = table.Column<float>(type: "real", nullable: false),
                    pro_price_offer = table.Column<int>(type: "int", nullable: true),
                    pro_image = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    pro_detail = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Products", x => x.pro_code);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Products");
        }
    }
}
