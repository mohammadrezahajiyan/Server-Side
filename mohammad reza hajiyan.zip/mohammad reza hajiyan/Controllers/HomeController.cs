﻿using System.Collections.Generic;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using mohammad_reza_hajiyan.Models;

namespace mohammad_reza_hajiyan.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        List<users> ListUsrs = new List<users>();
        users obj1 = new users();
        obj1.user_id = 1;
        obj1.nameandfamilyname = "mohammad reza hajiyan";
        obj1.email = "hajiyan29@gmail.com";
        obj1.password = "reza1381";
        obj1.repassword = "reza1381";
        obj1.phone = "09352628345";
        ListUsrs.Add(obj1);
        
        users obj2 = new users();
        obj2.user_id = 2;
        obj2.nameandfamilyname = "alireza ahmadi";
        obj2.email = "ahmadi94@gmail.com";
        obj2.password = "alireza1346";
        obj2.repassword = "alireza1346";
        obj2.phone = "09122628133";
        ListUsrs.Add(obj2);

        users obj3 = new users();
        obj3.user_id = 3;
        obj3.nameandfamilyname = "ebrahim gholami";
        obj3.email = "gholami54@gmail.com";
        obj3.password = "ebrahim1397";
        obj3.repassword = "ebrahim1397";
        obj3.phone = "09362628167";
        ListUsrs.Add(obj3);
        
        users obj4 = new users();
        obj4.user_id = 4;
        obj4.nameandfamilyname = "mahdi momeni";
        obj4.email = "momeni36@gmail.com";
        obj4.password = "mahdi9723";
        obj4.repassword = "mahdi9723";
        obj4.phone = "09102628139";
        ListUsrs.Add(obj4);

        users obj5 = new users();
        obj5.user_id = 5;
        obj5.nameandfamilyname = "ehsan jamali";
        obj5.email = "jamali13@gmail.com";
        obj5.password = "ehsan1397";
        obj5.repassword = "ehsan1397";
        obj5.phone = "09912628987";
        ListUsrs.Add(obj5);

        var query = ListUsrs.ToList();
        return View(query);
    }
    public IActionResult Login()
    {
        return View();
    }
    public IActionResult Register()
    {
        return View();
    }
    public IActionResult Contact()
    {
        return View();
    }

    public IActionResult About()
    {
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }
    public IActionResult question_order()
    {
        return View();
    }
    public IActionResult question_send_order()
    {
        return View();
    }
    public IActionResult return_product()
    {
        return View();
    }
    public IActionResult terms()
    {
        return View();
    }
    public IActionResult question_payment()
    {
        return View();
    }
    public IActionResult samsung()
    {
        return View();
    }
    public IActionResult apple()
    {
        return View();
    }
    public IActionResult huawei()
    {
        return View();
    }
    public IActionResult xiaomi()
    {
        return View();
    }
    

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
